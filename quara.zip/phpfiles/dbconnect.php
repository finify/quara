<?php
	$dbhost = 'localhost'; 
	$dbuser = 'root'; 
	$dbpass = ''; 
	$db ='quara';
	$con=mysqli_connect($dbhost,$dbuser,$dbpass,$db) ;
?>