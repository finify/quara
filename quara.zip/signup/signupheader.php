<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Quara</title>
<link rel="apple-touch-icon" sizes="76x76" href="../img/apple-icon.png">
<link rel="icon" type="image/png" sizes="96x96" href="../images/headlogo.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="signup.css" rel="stylesheet" />

<!-- CSS  -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="../css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  </head>

<body>
  <div class="wrapper">
    <center>
      <a href="../">
      <img src="../img/quara.png" width="180px" height="60px" title="schoolcrib"/> <br>
      </a>
    </center>